﻿// PASA Self-Assessment (NPS Act Section 4A)
PFMI Principle 1: Legal Basis — Compliant (NPS Act)
// ... (Full 24 principles template generated)
