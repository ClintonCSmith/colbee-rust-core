﻿PFMI Self-Assessment Template (CPMI-IOSCO 2025)
Principle 1: Legal Basis — Compliant (NPS Act 78/1998)
Principle 9: Money Settlements — Finality via sqlx ACID
// Full 24 principles (abridged for automation)
